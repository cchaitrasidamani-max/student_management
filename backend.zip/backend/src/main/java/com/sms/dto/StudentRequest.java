package com.sms.dto;

import com.sms.entity.Student;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;

@Data
public class StudentRequest {
    @NotBlank private String rollNumber;
    @NotBlank private String firstName;
    @NotBlank private String lastName;
    @Email @NotBlank private String email;
    @Pattern(regexp = "\\d{10}", message = "Phone number must be exactly 10 digits") private String phone;
    private String address;
    private LocalDate dateOfBirth;
    private Student.Gender gender;
    @NotNull private Long courseId;
    @NotNull @Min(1) @Max(8) private Integer semester;
    private Student.Status status;
}
