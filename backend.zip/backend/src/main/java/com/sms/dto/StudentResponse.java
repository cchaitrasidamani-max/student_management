package com.sms.dto;

import com.sms.entity.Student;
import lombok.Data;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class StudentResponse {
    private Long id;
    private String rollNumber;
    private String firstName;
    private String lastName;
    private String fullName;
    private String email;
    private String phone;
    private String address;
    private LocalDate dateOfBirth;
    private Student.Gender gender;
    private Long courseId;
    private String courseName;
    private String courseCode;
    private Integer semester;
    private Student.Status status;
    private LocalDateTime createdAt;

    public static StudentResponse from(Student s) {
        StudentResponse r = new StudentResponse();
        r.setId(s.getId());
        r.setRollNumber(s.getRollNumber());
        r.setFirstName(s.getFirstName());
        r.setLastName(s.getLastName());
        r.setFullName(s.getFullName());
        r.setEmail(s.getEmail());
        r.setPhone(s.getPhone());
        r.setAddress(s.getAddress());
        r.setDateOfBirth(s.getDateOfBirth());
        r.setGender(s.getGender());
        r.setSemester(s.getSemester());
        r.setStatus(s.getStatus());
        r.setCreatedAt(s.getCreatedAt());
        if (s.getCourse() != null) {
            r.setCourseId(s.getCourse().getId());
            r.setCourseName(s.getCourse().getName());
            r.setCourseCode(s.getCourse().getCode());
        }
        return r;
    }
}
