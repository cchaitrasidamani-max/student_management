package com.sms.dto;

import com.sms.entity.Result;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class ResultRequest {
    @NotNull private Long studentId;
    @NotBlank private String subject;
    @NotNull private Integer semester;
    @NotNull private Result.ExamType examType;
    @NotNull @Min(0) private Double marksObtained;
    @NotNull @Min(1) private Double maxMarks;
    private String remarks;
}
