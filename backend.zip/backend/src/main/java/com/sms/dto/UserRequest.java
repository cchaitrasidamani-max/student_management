package com.sms.dto;

import com.sms.entity.User;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class UserRequest {
    @NotBlank private String username;
    @NotBlank private String password;
    @NotBlank private String fullName;
    @Email @NotBlank private String email;
    @NotNull private User.Role role;
    @Pattern(regexp = "\\d{10}", message = "Phone number must be exactly 10 digits") private String phone;
}