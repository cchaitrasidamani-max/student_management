package com.sms.dto;

import com.sms.entity.Attendance;
import lombok.Data;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class AttendanceResponse {
    private Long id;
    private Long studentId;
    private String studentName;
    private String rollNumber;
    private String subject;
    private LocalDate attendanceDate;
    private Attendance.AttendanceStatus status;
    private String markedByName;
    private String remarks;
    private LocalDateTime createdAt;

    public static AttendanceResponse from(Attendance a) {
        AttendanceResponse r = new AttendanceResponse();
        r.setId(a.getId());
        r.setSubject(a.getSubject());
        r.setAttendanceDate(a.getAttendanceDate());
        r.setStatus(a.getStatus());
        r.setRemarks(a.getRemarks());
        r.setCreatedAt(a.getCreatedAt());
        if (a.getStudent() != null) {
            r.setStudentId(a.getStudent().getId());
            r.setStudentName(a.getStudent().getFullName());
            r.setRollNumber(a.getStudent().getRollNumber());
        }
        if (a.getMarkedBy() != null) {
            r.setMarkedByName(a.getMarkedBy().getFullName());
        }
        return r;
    }
}
