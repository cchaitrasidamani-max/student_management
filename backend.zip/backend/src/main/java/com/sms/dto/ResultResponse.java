package com.sms.dto;

import com.sms.entity.Result;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class ResultResponse {
    private Long id;
    private Long studentId;
    private String studentName;
    private String rollNumber;
    private String subject;
    private Integer semester;
    private Result.ExamType examType;
    private Double marksObtained;
    private Double maxMarks;
    private Double percentage;
    private String grade;
    private String enteredByName;
    private String remarks;
    private LocalDateTime createdAt;

    public static ResultResponse from(Result res) {
        ResultResponse r = new ResultResponse();
        r.setId(res.getId());
        r.setSubject(res.getSubject());
        r.setSemester(res.getSemester());
        r.setExamType(res.getExamType());
        r.setMarksObtained(res.getMarksObtained());
        r.setMaxMarks(res.getMaxMarks());
        r.setPercentage(res.getPercentage());
        r.setGrade(res.getGrade());
        r.setRemarks(res.getRemarks());
        r.setCreatedAt(res.getCreatedAt());
        if (res.getStudent() != null) {
            r.setStudentId(res.getStudent().getId());
            r.setStudentName(res.getStudent().getFullName());
            r.setRollNumber(res.getStudent().getRollNumber());
        }
        if (res.getEnteredBy() != null) {
            r.setEnteredByName(res.getEnteredBy().getFullName());
        }
        return r;
    }
}
