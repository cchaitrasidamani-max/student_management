package com.sms.dto;

import com.sms.entity.Attendance;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDate;

@Data
public class AttendanceRequest {
    @NotNull private Long studentId;
    @NotNull private String subject;
    @NotNull private LocalDate attendanceDate;
    @NotNull private Attendance.AttendanceStatus status;
    private String remarks;
}
